export const firebaseConfig ={
    apiKey: "AIzaSyBaK2n-7_tnXieqABqgNIBANGl78nlcJDc",
    authDomain: "fir-backend-50ec9.firebaseapp.com",
    databaseURL: "https://fir-backend-50ec9.firebaseio.com",
    projectId: "fir-backend-50ec9",
    storageBucket: "fir-backend-50ec9.appspot.com",
    messagingSenderId: "953988485617",
    appId: "1:953988485617:web:d593fdc8f4ddf1f9dc7450",
    measurementId: "G-97LTQBL9JY"
}